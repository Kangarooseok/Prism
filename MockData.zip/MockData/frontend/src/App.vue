<script setup>
import Default from '@/layouts/default.vue'
</script>

<template>
  <VApp>
    <Default />
  </VApp>
</template>
