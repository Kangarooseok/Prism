package prism.domain.group.command;

// CCTV 그룹 삭제 요청을 담는 커맨드 객체 (현재는 비어 있음)
public class DeleteCctvGroupCommand {
}
