package prism.domain.user.command;

import lombok.Data;

@Data
public class AssignUserToTeamCommand {

    private String assignedTeam;
}
