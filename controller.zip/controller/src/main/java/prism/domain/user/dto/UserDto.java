package prism.domain.user.dto;

public record UserDto(Long id, String username, String email, String role, String status) {}
