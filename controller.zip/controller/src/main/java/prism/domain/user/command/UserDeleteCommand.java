package prism.domain.user.command;

import lombok.Data;

@Data
public class UserDeleteCommand {}
