package prism.domain.cctv.command;

import lombok.Data;

@Data
public class DeleteCctvCommand {}
