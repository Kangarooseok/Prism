package prism.domain.cctv.command;

import lombok.Getter;
import lombok.Setter;

// CCTV 삭제 명령용 빈 커맨드 객체
@Getter
@Setter
public class DeleteCctvCommand {}
