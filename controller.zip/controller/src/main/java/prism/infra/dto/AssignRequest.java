package prism.infra.dto;

public record AssignRequest(Long groupId, Long userId) {}
