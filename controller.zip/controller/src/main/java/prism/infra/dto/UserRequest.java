package prism.infra.dto;

public class UserRequest {
}
