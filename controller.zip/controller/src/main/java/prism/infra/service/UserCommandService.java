package prism.infra.service;

public class UserCommandService {
}
