
package prism.infra.service;
public class CctvCommandService {
}
